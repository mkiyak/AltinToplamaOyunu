Mehmet KIYAK 180201135
Derya ÖZGÜ 180201115
                                                             
Bu program Windows 10 isletim sistemi uzerinde "Microsoft Visual Studio Preview" kullanilarak yazilmistir.
Visual Studio surumu 2019 kullanılmıştır.
                                                    ALTIN TOPLAMA OYUNU PROJESİ

1-PAKETIN ICINDEKILER:

180201115-180201135.txt - Programin tek dosyaya indirgenmis kaynak kodu
readme.txt - Programi calistirmak icin gerekli bilgiler
180201115-180201135.zip - Projenin kaynak kodunun ve yardimci dosyalarin ziplenmis hali
Rapor.docx - IEEE formatinda Proje raporu

2-KURULUM

Programimiz yazilim gelistirme ortamlarindan biri olan "C#" ile yazilmistir. Programi calistirmak icin "https://visualstudio.microsoft.com/tr/downloads/"  bu adrese girerek
bilgisayariniza Visual Studio 2019 programı veya üst sürümlerini kurabilirsiniz. Detayli anlatimlar icin "https://www.youtube.com/watch?v=VKpyd6f3cFk" bu linki kullanabilirsiniz.

3-PROGRAMIN CALISTIRILMASI 

Gerekli indirme islemleri tamamlandiktan sonra Visual Studio programini aciniz. Karsiniza gelen ekranda klasor seç diyerek indirmiş olduğunuz dosyaları dışarı çıkartıp klasörü eçerek ileri demeniz yeterli olacaktır.